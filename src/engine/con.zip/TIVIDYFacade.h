#ifndef TIVIDYFACADE_H
#define TIVIDYFACADE_H

#include "WorkflowDefinition.h"
#include "WorkflowInstance.h"
#include "Participant.h"
#include "WorkflowHistory.h"
#include "WorkflowBuilder.h"
#include "WorkflowDirector.h"

#include <map>
#include <string>
#include <vector>

namespace tividy {
class ConcreteWorkflowBuilder;

/**
 * @brief Facade exposing common workflow operations through a small interface.
 *
 * The facade does not own the definitions, instances, or work items supplied
 * by callers. createWorkflow() and startWorkflow() return allocated objects
 * that the caller must delete.
 * The facade does not manage the lifetime of any other objects. It is the
 * caller's responsibility to ensure that any definitions, instances, or work
 * The facade allows the client to create and manage all of the workflow instances created and definitions
 * Allowing clients to switch between different workflow definitions and instances without needing to know the underlying implementation details.
 * items supplied to it remain valid for the duration of their use.
 */
	class TIVIDYFacade {
	public:
    /** @brief Construct a facade with no definitions or instances. */
    TIVIDYFacade();

    /**
     * @brief Destroy the facade's builders.
     *
     * Definitions and instances are not deleted here; their owners still
     * delete them, instances before the definitions they came from.
     */
    ~TIVIDYFacade();

    /** @brief Copying is disabled because the facade owns its builders. */
    TIVIDYFacade(const TIVIDYFacade&) = delete;
    TIVIDYFacade& operator=(const TIVIDYFacade&) = delete;

	/**
     * @brief Allocate an empty workflow definition.
     * @return Newly allocated definition; caller owns the returned pointer.
     */
		WorkflowDefinition* createWorkflow(const std::string& name);

  /*
  *@brief Default constructor
  */
    WorkflowDefinition* createWorkflow();

	/**
     * @brief Create an instance from a definition, then submit and activate it.
     * @param definition Definition to use; must not be null and must outlive the instance.
     * @return Newly allocated workflow instance; caller owns it.
     * @throws std::invalid_argument If @p definition is null.
     */
		WorkflowInstance* startWorkflow(WorkflowDefinition* definition);

	/**
     * @brief Execute a work item without recording a participant assignment.
     *
     * This overload is useful when the caller manages assignment separately.
     * It does not update participant workload. Use the overload that accepts
     * candidate participants when the Facade should select and record an
     * instance-aware assignment.
     *
     * @param instance Workflow instance argument; must not be null.
     * @param item Work item to execute; must not be null.
     * @throws std::invalid_argument If either argument is null.
     */
		void assignWork(WorkflowInstance* instance, WorkItem* item);

	/**
     * @brief Mark an item complete for an instance without a participant.
     *
     * Completion is recorded in the instance's progress records. The workflow
     * is resolved only when all tracked items in that instance are complete.
     * Because no participant is supplied, this overload cannot update any
     * participant's workload. Use the overload that accepts a participant
     * when completing a recorded assignment.
     *
     * @param instance Workflow instance; must not be null.
     * @param item Work item to mark complete; must belong to the instance.
     * @throws std::invalid_argument If either argument is null or the item
     *         does not belong to the instance.
     */
		void completeWork(WorkflowInstance* instance, WorkItem* item);

	/**
     * @brief Request escalation of a workflow instance.
     * @param instance Instance to escalate; must not be null and must be in progress.
     * @throws std::invalid_argument If @p instance is null.
     * @throws std::logic_error If escalation is not allowed or no handler is configured.
     */
		void escalateWork(WorkflowInstance* instance);

	/**
     * @brief Close a workflow instance.
     * @param instance Instance to close; must not be null and the state must allow closure.
     * @throws std::invalid_argument If @p instance is null.
     * @throws std::logic_error If the state rejects closure.
     */
		void closeWorkflow(WorkflowInstance* instance);

        /**
         * @brief Select and record an instance-aware participant assignment.
         * @param instance Workflow instance to which the item belongs.
         * @param item Work item to assign.
         * @param participants Candidate participants passed to the configured strategy.
         * @return Selected participant, or nullptr when no suitable candidate exists.
         * @throws std::invalid_argument If the instance or item is null.
         * @throws std::logic_error If the instance has no workflow definition.
         */
        Participant* assignWork(
            WorkflowInstance* instance,
            WorkItem* item,
            std::vector<Participant*> participants
        );

        /**
         * @brief Complete an instance-aware assignment and update participant workload.
         * @param instance Workflow instance associated with the assignment.
         * @param item Work item being completed.
         * @param participant Participant who holds the assignment.
         * @throws std::invalid_argument If any argument is null.
         */
        void completeWork(
            WorkflowInstance* instance,
            WorkItem* item,
            Participant* participant
        );

        /**
         * @brief Add a new work item to one running instance only.
         * @param instance Running workflow instance.
         * @param name Unique work-item name.
         * @param requiredRole Role required for the new item.
         * @param dependency Optional existing prerequisite in the same instance.
         * @return The new instance-owned work item.
         */
        WorkItem* addWorkItemToInstance(
            WorkflowInstance* instance,
            const std::string& name,
            const std::string& requiredRole,
            WorkItem* dependency = nullptr
        );

        /** @brief Cancel an incomplete item in one workflow instance. */
        void cancelWorkItem(WorkflowInstance* instance, WorkItem* item);

        /** @brief Reassign an incomplete item to a participant in that instance. */
        void reassignWorkItem(
            WorkflowInstance* instance,
            WorkItem* item,
            Participant* participant
        );

        /** @brief Change an incomplete item's required role in one instance. */
        void changeWorkItemRole(
            WorkflowInstance* instance,
            WorkItem* item,
            const std::string& requiredRole
        );

        /** @brief Change an incomplete item's priority in one instance. */
        void changeWorkItemPriority(
            WorkflowInstance* instance,
            WorkItem* item,
            int priority
        );

        /**
         * @brief Add a participant to one workflow instance.
         * @param takeOwnership If true, the instance deletes the participant.
         */
        void addParticipantToInstance(
            WorkflowInstance* instance,
            Participant* participant,
            bool takeOwnership = false
        );

        /** @brief Return the current assignee of an item, or nullptr. */
        Participant* getAssignee(WorkflowInstance* instance, WorkItem* item) const;

        /** @brief Return participants available to one workflow instance. */
        std::vector<Participant*> getParticipantObjects(WorkflowInstance* instance) const;

        /** @brief Return incomplete work currently assigned in one instance. */
        std::vector<WorkItem*> getAssignedWorkItems(WorkflowInstance* instance) const;

            /**
          * @brief Return the history of state changes for a workflow instance.
          * @param instance Workflow instance to query; must not be null.
          * @return String describing the history of state changes and events.
          * @throws std::invalid_argument If @p instance is null.
          */
        std::string getHistory(WorkflowInstance* instance);

            /**
          * @brief Return the progress of a workflow instance as a percentage.
          * @param instance Workflow instance to query; must not be null.
          * @return Progress percentage (0.0 to 100.0).
          * @throws std::invalid_argument If @p instance is null.
          */
        double getProgress(WorkflowInstance* instance);

            /**
          * @brief Return the incomplete work items for a workflow instance.
          * @param instance Workflow instance to query; must not be null.
          * @return Vector of pointers to incomplete work items.
          * @throws std::invalid_argument If @p instance is null.
          */
        std::vector<WorkItem*> getIncompleteWorkItems(WorkflowInstance* instance);

        
        /**
         * @brief Return the complete work items for a workflow instance.
         * @param instance Workflow instance to query; must not be null.
         * @return Vector of pointers to complete work items.
         * @throws std::invalid_argument If @p instance is null.
         */
        std::vector<std::string> getParticipants(WorkflowInstance* instance);

        /**
          * @brief Return all work items for a workflow instance.
          * @param instance Workflow instance to query; must not be null.
          * @return Vector of pointers to work items.
          * @throws std::invalid_argument If @p instance is null.
          */
        std::vector<WorkItem*> getAllWorkItems(WorkflowInstance* instance);

            /**
           * @brief Return all workflow definitions created by the facade.
           * @return Vector of pointers to workflow definitions.
           */
        std::vector<WorkflowInstance*> getAllInstances() const;

        /**
          * @brief Return all workflow definitions created by the facade.
          * @return Vector of pointers to workflow definitions.
          */
        std::vector<WorkflowDefinition*> getAllDefinitions() const;

        /**
          * @brief Return all workflow instances associated with a specific definition.
          * @param definition Workflow definition to query; must not be null.
          * @return Vector of pointers to workflow instances associated with the definition.
          * @throws std::invalid_argument If @p definition is null.
          */
        std::vector<WorkflowInstance*> getInstancesForDefinition(WorkflowDefinition* definition) const;

        /**
          * @brief Return all roles associated with a specific workflow definition.
          * @param definition Workflow definition to query; must not be null.
          * @return Vector of role names associated with the definition.
          * @throws std::invalid_argument If @p definition is null.
          */
        std::vector<Role<void>*> getRolesForDefinition(WorkflowDefinition* definition) const;

        /**
          * @brief Configure the assignment strategy for a specific workflow definition.
          * @param definition Workflow definition for which to configure the strategy; must not be null.
          * @param strategy Assignment strategy to configure; must not be null.
          * @throws std::invalid_argument If either argument is null.
          */
        void configureAssignmentStrategy(WorkflowDefinition* definition, AssignmentStrategy* strategy);

        /**
          * @brief Configure the escalation handler for a specific workflow definition.
          * @param definition Workflow definition for which to configure the handler; must not be null.
          * @param handler Escalation handler to configure; must not be null.
          * @throws std::invalid_argument If either argument is null.
          */
        void configureEscalationHandler(WorkflowDefinition* definition, Handler* handler);

        /**
          * @brief Add a role to a specific workflow definition.
          * @param definition Workflow definition to which the role will be added; must not be null.
          * @param roleName Name of the role to add; must not be empty.
          * @throws std::invalid_argument If @p definition is null or @p roleName is empty.
          */
       void addRoleToDefinition(WorkflowDefinition* definition,Role<void>* role);

       /**
          * @brief Add a work item to a specific workflow definition.
          * @param definition Workflow definition to which the work item will be added; must not be null.
          * @param item Work item to add; must not be null.
          * @throws std::invalid_argument If either argument is null.
          */
       void addWorkItemToDefinition(WorkflowDefinition* definition, WorkItem* item);

       /**
          * @brief Add a dependency to a specific work item within a workflow definition.
          * @param definition Workflow definition containing the work item; must not be null.
          * @param item Work item to which the dependency will be added; must not be null.
          * @param dependency Dependency to add; must not be null.
          * @throws std::invalid_argument If any argument is null.
          */
       void addDependencyToWorkItem(WorkflowDefinition* definition, WorkItem* item, WorkItem* dependency);

       /**
          * @brief Add a priority to a specific work item within a workflow definition.
          * @param definition Workflow definition containing the work item; must not be null.
          * @param item Work item to which the priority will be added; must not be null.
          * @param priority Priority to add; must be a valid integer.
          * @throws std::invalid_argument If any argument is null.
          */
       void addPriorityToWorkItem(WorkflowDefinition* definition, WorkItem* item, int priority);

       /**
         * @brief Create a work item owned by the definition and add it to the work structure.
         * @param definition Definition to add to; must not be null.
         * @param name Non-blank item name.
         * @param requiredRole Role required for the item; may be empty.
         * @return The new item; the definition owns it, do not delete it.
         * @throws std::invalid_argument If @p definition is null or @p name is blank.
         */
       WorkItem* createWorkItemInDefinition(WorkflowDefinition* definition,
                                            const std::string& name,
                                            const std::string& requiredRole = std::string());

       /** @brief Open a nested sub-process in the definition; later items go inside it. */
       void beginSubProcessInDefinition(WorkflowDefinition* definition);

       /** @brief Close the innermost open sub-process of the definition. */
       void endSubProcessInDefinition(WorkflowDefinition* definition);

       /**
         * @brief Create a participant owned by the definition.
         *
         * Instances started from the definition afterwards include the participant.
         * @param definition Definition to add to; must not be null.
         * @param name Non-blank participant name, unique within the definition.
         * @param role Optional first role; also registered as a role of the definition.
         * @return The new participant; the definition owns it, do not delete it.
         * @throws std::invalid_argument On a null definition or a blank/duplicate name.
         */
       Participant* createParticipantInDefinition(WorkflowDefinition* definition,
                                                  const std::string& name,
                                                  const std::string& role = std::string());

       /**
         * @brief Register an existing, caller-owned participant with a definition.
         * @throws std::invalid_argument On null arguments or a blank/duplicate name.
         */
       void addParticipantToDefinition(WorkflowDefinition* definition, Participant* participant);

       /**
         * @brief Return the participants registered with a definition.
         * @throws std::invalid_argument If @p definition is null.
         */
       std::vector<Participant*> getParticipantsForDefinition(WorkflowDefinition* definition) const;

       /** @brief Return every participant registered with any definition, without duplicates. */
       std::vector<Participant*> getAllParticipants() const;

       /**
         * @brief Create a definition whose steps run one after another.
         * @param name Name of the new definition.
         * @param steps Recipe passed to WorkflowDirector::constructSequentialWorkflow.
         * @return New definition registered with the facade.
         * @throws std::invalid_argument If a step is invalid; nothing is created.
         */
       WorkflowDefinition* createSequentialWorkflow(const std::string& name,
                                                    const std::vector<WorkflowStep>& steps);

       /** @brief Return a definition's name. @throws std::invalid_argument If null. */
       std::string getDefinitionName(WorkflowDefinition* definition) const;

     private:
        std::vector<WorkflowDefinition*> definitions;
        std::vector<WorkflowInstance*> instances;

        /** @brief One builder per definition, kept so priority and nesting state persists. Owned. */
        std::map<WorkflowDefinition*, ConcreteWorkflowBuilder*> builders;

        /** @brief Find or create the builder that edits @p definition. */
        ConcreteWorkflowBuilder& builderFor(WorkflowDefinition* definition);
	};


} // namespace tividy

#endif // TIVIDYFACADE_H
